/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question7;

/**
 *
 * @author educa
 */import java.util.Scanner;
public class Question7 {

    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        
        System.out.print("Enter the number for the diamond (half): ");
        int n = obj.nextInt();
        for (int i = 1; i <= n; i++) {
        for (int j = n; j > i; j--) {
        System.out.print(" ");
        }
            
        for (int k = 1; k <= (2 * i - 1); k++) {
        System.out.print("*");
        }
            
        System.out.println();
        }
        for (int i = n - 1; i >= 1; i--) {
            for (int j = n; j > i; j--) {
                System.out.print(" ");
            }
            
         for (int k = 1; k <= (2 * i - 1); k++) {
        System.out.print("*");
            }
        System.out.println();
        }

      
        }
        }

        

      
        
        


        
    

