/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question8;

/**
 *
 * @author educa
 */
public class Question8 {

    public static void main(String[] args) {
          
        int[] nums = {10, 12, 34, 23, 56, 78};
        
        int sum = 0;
        for (int number : nums) {
            sum = sum+number;
        }
        float Avrg =  sum / nums.length;
        
        System.out.println("The average of the array elements is: " + Avrg);
    }
}

        
    

