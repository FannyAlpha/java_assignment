/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question9;

/**
 *
 * @author educa
 */
public class Question9 {

    public static void main(String[] args) {  
    int[] nums = {3, 4, 6, 1, 9, 7, 5, 8}; 
    int[] reversed = new int[nums.length];
    for (int r = 0; r< nums.length; r++) {
    reversed[r] = nums[nums.length - 1 - r];
    }
        System.out.print("Reversed array: ");
        for (int number : reversed) {
            System.out.print(number + " ");
        }
    }
}

    

