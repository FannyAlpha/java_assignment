/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question10;

/**
 *
 * @author educa
 */
public class Question10 {

    public static void main(String[] args) {
         int[] nums = {34, 23, 12, 45, 67, 89, 234, 26, 10, 30, 43};
        int largest = nums[0];
        
        // Loop through the array to find the largest element
        for (int i = 1; i < nums.length; i++) {
            if (nums[i] > largest) {
                largest = nums[i];
            }
        }
       
        System.out.println("The largest element in the array is: " + largest);
    }
}

    

