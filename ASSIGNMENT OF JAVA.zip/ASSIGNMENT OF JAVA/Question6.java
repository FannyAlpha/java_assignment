/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question6;

/**
 *
 * @author educa
 */import java.util.Scanner;
public class Question6 {

    public static void main(String[] args) {
         Scanner obj = new Scanner(System.in);
        
        System.out.print("Enter the number of rows for the right-angled triangle: ");
        int rows = obj.nextInt();
        
        
        for (int j = 1; j <= rows; j++) {
            
            for (int k =j; k >= 1; k--) {
                System.out.print(k);
            }
        
            System.out.println();
        }

        obj.close();
    }
}

    


