/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question5;

/**
 *
 * @author educa
 */import java.util.Scanner;
public class Question5 {

    public static void main(String[] args) {
        
    Scanner obj=new Scanner(System.in);
    int n;
    System.out.println("enter number");
   n=obj.nextInt();
   if(n>0){
       System.out.println(n+"is positive");
   }
   else if(n<0){
       System.out.println(n+"is negative");
   }
   else
       System.out.println(n+"is zero");
}
}

    

